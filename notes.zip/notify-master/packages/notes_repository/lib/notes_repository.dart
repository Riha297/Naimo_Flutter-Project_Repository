library notes_repository;

export 'src/notes_repository.dart';
export 'package:notes_api/notes_api.dart' show Note;
