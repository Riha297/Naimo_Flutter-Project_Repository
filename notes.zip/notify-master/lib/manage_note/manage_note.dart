export 'cubit/manage_note_cubit.dart';
export 'view/view.dart';
