export 'cubit/note_cubit.dart';
export 'view/view.dart';
